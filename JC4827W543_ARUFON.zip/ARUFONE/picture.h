
int ww = 0;
int r = 0;
int o = 0;
int y = 0;
int g = 0;
int c = 0;
int b = 0;
int m = 0;
int s1 = 0;
int s2 = 0;
int s3 = 0;
int s4 = 0;
int l = 0;
int color = RGB565_WHITE;
int SSS = 2;
void drawUnit(){
gfx->fillRect(460, 0, 20, 20, RGB565_WHITE);
gfx->fillRect(460, 20, 20, 20, RGB565_RED);
gfx->fillRect(460, 40, 20, 20, RGB565_ORANGE);
gfx->fillRect(460, 60, 20, 20, RGB565_YELLOW);
gfx->fillRect(460, 80, 20, 20, RGB565_GREEN);
gfx->fillRect(460, 100, 20, 20, RGB565_CYAN);
gfx->fillRect(460, 120, 20, 20, RGB565_BLUE);
gfx->fillRect(460, 140, 20, 20, RGB565_MAGENTA);
gfx->fillCircle(470, 170, 2, RGB565_WHITE);
gfx->fillCircle(470, 190, 4, RGB565_WHITE);
gfx->fillCircle(470, 210, 6, RGB565_WHITE);
gfx->fillCircle(470, 230, 7, RGB565_WHITE);
gfx->draw16bitBeRGBBitmap(460, 250, ss, 20, 20);
gfx->draw16bitBeRGBBitmap(0, 242, back, 40, 30);
}

void picture(){
gfx->fillScreen(RGB565_BLACK);
drawUnit();
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
// ОБРАБАТУЕМ ДАННЫЕ НАЖАТИЯ НА ЦВЕТА РАЗМЕР
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 0 && ty <= 0 + 20 ){
 ww = 1;r = 0;o = 0;y = 0;g = 0;c = 0;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 20 && ty <= 20 + 20 ){
 ww = 0;r = 1;o = 0;y = 0;g = 0;c = 0;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 40 && ty <= 40 + 20 ){
ww = 0;r = 0;o = 1;y = 0;g = 0;c = 0;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 60 && ty <= 60 + 20 ){
ww = 0;r = 0;o = 0;y = 1;g = 0;c = 0;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 80 && ty <= 80 + 20 ){
ww = 0;r = 0;o = 0;y = 0;g = 1;c = 0;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 100 && ty <= 100 + 20 ){
ww = 0;r = 0;o = 0;y = 0;g = 0;c = 1;b = 0;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 120 && ty <= 120 + 20 ){
ww = 0;r = 0;o = 0;y = 0;g = 0;c = 0;b = 1;m = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 140 && ty <= 140 + 20 ){
ww = 0;r = 0;o = 0;y = 0;g = 0;c = 0;b = 0;m = 1;
    }
//РАЗМЕР
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 170 && ty <= 170 + 20 ){
 s1 = 1;s2 = 0;s3 = 0;s4 = 0;l = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 190 && ty <= 190 + 20 ){
 s1 = 0;s2 = 1;s3 = 0;s4 = 0;l = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 210 && ty <= 210 + 20 ){
 s1 = 0;s2 = 0;s3 = 1;s4 = 0;l = 0;
    }
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 220 && ty <= 220 + 20 ){
 s1 = 0;s2 = 0;s3 = 0;s4 = 1;l = 0;
    }
if (tx >= 400 && tx <= 400 + 40 &&
    ty >= 230 && ty <= 230 + 40 ){
 gfx->fillScreen(RGB565_BLACK);drawUnit();delay(100);
    }
if (tx >= 0 && tx <= 0 + 20 &&
    ty >= 252 && ty <= 252 + 20 ){
MeNu();
    }
//ОБРАБОТКА ЦВЕТА
if(ww == 1){
color = RGB565_WHITE;drawUnit();
}
if(r == 1){
color = RGB565_RED;drawUnit();
}
if(o == 1){
color = RGB565_ORANGE;drawUnit();
}
if(y == 1){
color = RGB565_YELLOW;drawUnit();
}
if(g == 1){
color = RGB565_GREEN;drawUnit();
}
if(c == 1){
color = RGB565_CYAN;drawUnit();
}
if(b == 1){
color = RGB565_BLUE;drawUnit();
}
if(m == 1){
color = RGB565_MAGENTA;drawUnit();
}
//ОБРАБОТКА РАЗМЕРА
if(s1 == 1){
SSS = 2;drawUnit();
}
if(s2 == 1){
SSS = 4;drawUnit();
}
if(s3 == 1){
SSS = 6;drawUnit();
}
if(s4 == 1){
SSS = 7;drawUnit();
}
// ОБРАБОТКА ЛАСТИКА
if (tx >= 460 && tx <= 460 + 20 &&
    ty >= 250 && ty <= 250 + 20 ){
    ww = 0;r = 0;o = 0;y = 0;g = 0;c = 0;b = 0;m = 0;
    color = RGB565_BLACK;drawUnit();
    }

gfx->fillCircle(tx, ty, SSS, color);
}}}}