     int screenW = gfx->width();
  int screenH = gfx->height();
   int arrowSize = 40;
    int margin = 10;
    int playButtonSize = 50;
    int playX = (screenW - playButtonSize) / 2;
    int playY = screenH - playButtonSize - 20;

// Continuously read until no touches are registered.
void waitForTouchRelease()
{
  while (touchController.touches > 0)
  {
    touchController.read();
    delay(50);
  }
  // Extra debounce delay to ensure that the touch state is fully cleared.
  delay(300);
}

void displaySelectedFile()
{
  // Clear the screen
  gfx->fillScreen(RGB565_BLACK);


  int centerY = screenH / 2;
  int arrowSize = 40; // size of the arrow icon (adjust as needed)
  int margin = 10;    // margin from screen edge
gfx->draw16bitBeRGBBitmap(440, 0, back, 40, 30);
  // --- Draw Left Arrow ---
  // The left arrow is drawn as a filled triangle at the left side.
  gfx->fillTriangle(margin, centerY,
                    margin + arrowSize, centerY - arrowSize / 2,
                    margin + arrowSize, centerY + arrowSize / 2,
                    RGB565_WHITE);

  // --- Draw Right Arrow ---
  // Draw the right arrow as a filled triangle at the right side.
  gfx->fillTriangle(screenW - margin, centerY,
                    screenW - margin - arrowSize, centerY - arrowSize / 2,
                    screenW - margin - arrowSize, centerY + arrowSize / 2,
                    RGB565_WHITE);

  // --- Draw the Title ---
  // Get the file title string.
  String title = gifFileList[currentFile];
  int16_t x1, y1;
  uint16_t textW, textH;
  gfx->getTextBounds(title.c_str(), 0, 0, &x1, &y1, &textW, &textH);
  // Calculate x so the text is centered.
  int titleX = (screenW - textW) / 2 - x1;
  // Position the title above the play button; here we place it at roughly one-third of the screen height.
  int titleY = screenH / 3;
  gfx->setCursor(titleX, titleY);
  gfx->print(title);

  // --- Draw the Play Button ---
  // Define the play button size and location.
  int playButtonSize = 50;
  int playX = (screenW - playButtonSize) / 2;
  int playY = screenH - playButtonSize - 20; // 20 pixels from bottom
  // Draw a filled circle for the button background.
  gfx->fillCircle(playX + playButtonSize / 2, playY + playButtonSize / 2, playButtonSize / 2, RGB565_DARKGREEN);
  // Draw a play–icon (triangle) inside the circle.
  int triX = playX + playButtonSize / 2 - playButtonSize / 4;
  int triY = playY + playButtonSize / 2;
  gfx->fillTriangle(triX, triY - playButtonSize / 4,
                    triX, triY + playButtonSize / 4,
                    triX + playButtonSize / 2, triY,
                    RGB565_WHITE);
}






void galerea(){
  gfx->setFont(&FreeSansBold12pt7b);
  displaySelectedFile();
  while(1){
  touchController.read();
  if (touchController.touches > 0){
  
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    Serial.printf("x=%d, y=%d\n", tx, ty);
    int screenW = gfx->width();
    int screenH = gfx->height();




if (tx >= 440 && tx <= 440 + 40 &&
    ty >= 0 && ty <= 0 + 40 ){
    MeNu();
    }
    // Check if touch is in the left arrow area.
    if (tx < margin + arrowSize && ty > (screenH / 2 - arrowSize) && ty < (screenH / 2 + arrowSize))
    {
      // Left arrow touched: cycle to previous file.
      currentFile--;
      if (currentFile < 0)
        currentFile = fileCount - 1;
      updateTitle();
      while (touchController.touches > 0)
      {
        touchController.read();
        delay(50);
      }
      delay(300);
    }
    else if (tx > screenW - margin - arrowSize && ty > (screenH / 2 - arrowSize) && ty < (screenH / 2 + arrowSize))
    {
      // Right arrow touched: cycle to next file.
      currentFile++;
      if (currentFile >= fileCount)
        currentFile = 0;
      updateTitle();
      while (touchController.touches > 0)
      {
        touchController.read();
        delay(50);
      }
      delay(300);
    }
    // Check if touch is in the play button area.
    else if (tx >= playX && tx <= playX + playButtonSize &&
             ty >= playY && ty <= playY + playButtonSize)
    {
      playSelectedFile(currentFile);
      // Wait until the user fully releases the touch before refreshing the UI.
      waitForTouchRelease();

      // After playback, redisplay the selection screen.
      displaySelectedFile();
      while (touchController.touches > 0)
      {
        touchController.read();
        delay(50);
      }
      delay(300);
    }
  }
  delay(50);
}}




