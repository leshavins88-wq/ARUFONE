
void OFF (){
  gfx->fillScreen(RGB565_BLACK);
  delay(1000);
playSelectedFile(2);
delay(10000);
gfx->fillScreen(RGB565_BLACK);
 digitalWrite(GFX_BL, LOW); // Set the backlight of the screen to High intensity
while(1){
  touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();

//ЕСЛИ БЫЛО НАЖАТИЕ НА ЭКРАН

if (tx >= 50 && tx <= 50 + 100 &&
    ty >= 50 && ty <= 50 + 100 ){
  digitalWrite(GFX_BL, HIGH); // Set the backlight of the screen to High intensity
  playSelectedFile(2);
delay(10000);
MeNu();
    }
}}}}