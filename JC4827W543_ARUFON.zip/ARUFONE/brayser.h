
void brayser (){
gfx->setRotation(0);
 playSelectedFile(19);
gfx->setRotation(1);
int count1 = 0;
int count2 = 40;
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   // в меню
   if (tx >= 440 && tx <= 440 + 40 &&
    ty >= 230 && ty <= 230 + 40 ){
MeNu();
    }

   // ВВОД КЛАВИШ
    if (tx >= 10 && tx <= 20 + 100 &&
        ty >= 10 && ty <= 10 + 100 ){
    gfx->setTextSize(1);
    gfx->setTextColor(RGB565_WHITE);
    gfx->setCursor(count2, 65);  
   gfx->print("0");
   delay(500);
   count2 = count2 + 10;
        }
  
  if (tx >= 10 && tx <= 20 + 100 &&
        ty >= 110 && ty <= 110 + 100 ){
    gfx->setTextSize(1);
    gfx->setTextColor(RGB565_WHITE);
   gfx->setCursor(count2, 65);  
   gfx->print("1");
   count2 = count2 + 10;
    count1 = count1 + 1;
   delay(500);
        }


// ПОИСК
if (tx >= 400 && tx <= 400 + 70 &&
    ty >= 200 && ty <= 200 + 70 ){
// набил факты о богомолах
if (count1 == 2){
gfx->fillScreen(RGB565_BLACK);
    gfx->setTextSize(1);
    gfx->setTextColor(RGB565_WHITE);
   gfx->setCursor(10, 10);  
   gfx->print("The name was given by the Swedish naturalist Carl Linnaeus in honor of the praying mantis waiting hunting posture, where it folds its front limbs in a manner similar to how a person clasps their hands in prayer.In Greek, the name of these insects translates to predictor or prophet, while in Latin, it means religious.The female praying mantis is larger than the male, with a length of up to 75 mm.Praying mantises prey on a variety of insects, as well as small lizards, frogs, and even birds.");
gfx->draw16bitBeRGBBitmap(50,200, mantis, 150, 100);
gfx->draw16bitBeRGBBitmap(0, 450, back, 40, 30);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   // в меню
if (tx >= 10 && tx <= 10 + 250 &&
    ty >= 10 && ty <= 10 + 450 ){
 brayser();
    }
}}}}
// если цифровой цирк
if (count1 == 4){
gfx->fillScreen(RGB565_BLACK);
    gfx->setTextSize(2);
    gfx->setTextColor(RGB565_WHITE);
   gfx->setCursor(10, 10);  
   gfx->print("A girl named Remember enters a digital circus through a VR headset, where she meets five other characters (Ragata, Gangle, Koroleer, Zubl, and Jex) who, like her, do not remember their own names. They are all former humans, but now they are trapped in the bodies of cartoonish avatars in a simulation created by an artificial intelligence named Kane. He acts as an entertainer and organizes adventures for the circus residents so that they dont disperse and go crazy or turn into digital monsters. ");
gfx->draw16bitBeRGBBitmap(0, 450, back, 40, 30);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   // в меню
if (tx >= 10 && tx <= 10 + 250 &&
    ty >= 10 && ty <= 10 + 450 ){
 brayser();
    }
}}}}
// если о аруфоне
if (count1 == 6){
gfx->fillScreen(RGB565_BLACK);
    gfx->setTextSize(2);
    gfx->setTextColor(RGB565_WHITE);
   gfx->setCursor(10, 10);  
   gfx->print("Arufon is a phone with dual memory - 2.6 gigabytes based on a two-core esp32 s3 that supports WIFI and BLUETOOTH with a 4g format. The processor is very good, with a total of 280 MHz and its own PSRAM memory. The phone itself has a 4.3-inch display with a resolution of 480 by 272 pixels! And it has a very good response time! It also supports SD card speakers, a battery, and other pins for various purposes, as well as a type-C connector! This phone features a beautiful interface with games, shutdown, settings, a gallery, a browser, internet, and more! This phone was designed as a DIY phone! The phone was created by Koltsov Artem Alekseevich. ");
gfx->draw16bitBeRGBBitmap(0, 450, back, 40, 30);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   // в меню
if (tx >= 10 && tx <= 10 + 250 &&
    ty >= 10 && ty <= 10 + 450 ){
 brayser();
    }
}}}}
//если о 3д принтере
if (count1 == 8){
gfx->fillScreen(RGB565_BLACK);
    gfx->setTextSize(2);
    gfx->setTextColor(RGB565_WHITE);
   gfx->setCursor(10, 10);  
   gfx->print("3D printer is a term that means a device that creates three-dimensional objects in the real world from a digital model.Types FDM printers - print products from a plastic filament (filament). Printing principle: the printer heats the plastic to melting and extrudes it through a nozzle in a thin stream, forming the layers of the object in a sequential manner. Photopolymer printers - layer by layer create a model from a liquid resin, the material hardens under the influence of ultraviolet light. During printing, the platform is immersed in a resin bath, and the screen or laser illuminates the desired areas of the layer, causing the resin to polymerize and become solid.");
gfx->draw16bitBeRGBBitmap(0, 450, back, 40, 30);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   // в меню
if (tx >= 10 && tx <= 10 + 250 &&
    ty >= 10 && ty <= 10 + 450 ){
 brayser();
    }
}}}}


        }
  






}}}}