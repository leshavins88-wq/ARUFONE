#include "picture.h"
#include "gd.h"
void playtoy (){
playSelectedFile(3);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
if (tx >= 10 && tx <= 10 + 240 &&
    ty >= 10 && ty <= 10 + 90 ){
while(1){
 menu5();   
}}

if (tx >= 10 && tx <= 10 + 240 &&
    ty >= 180 && ty <= 180 + 90 ){
while(1){
picture();


    }}


if (tx >= 440 && tx <= 440 + 40 &&
    ty >= 230 && ty <= 230 + 40  ){ 
   MeNu();
    }




}}}}