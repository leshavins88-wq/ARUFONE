
void settings (){
playSelectedFile(17);
while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();

if (tx >= 240 && tx <= 240 + 40 &&
    ty >= 5 && ty <= 5 + 250 ){
    playSelectedFile(16);
    while(1){
      touchController.read();
       if (touchController.isTouched){
        for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
    if (tx >= 50 && tx <= 50 + 80 &&
    ty >= 50 && ty <= 50 + 80 ){
    settings();
    }}}}}
if (tx >= 60 && tx <= 60 + 200 &&
    ty >= 5 && ty <= 5 + 250 ){
    playSelectedFile(18);
    settings();
    }

if (tx >= 440 && tx <= 440 + 40 &&
    ty >= 230 && ty <= 230 + 40 ){
    MeNu();
    }

}}}}