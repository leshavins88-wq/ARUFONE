// мне было лень его доделывать так что это просто обрезки моего предыдущего проекта, также я не захотел это доделовать из за ошибок и не стыковок переноса стого проекта на этот
int mode = 0; // Переменная для хранения текущего режима
int buf_mode = 0; //Буферная переменная
void menu10(){
playSelectedFile(9);
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
  int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
if (tx >= 5 && tx <= 5 + 40 &&
    ty >= 5 && ty <= 5 + 40  ){ 
    MeNu();
    }

    }}}

void menu30(){
playSelectedFile(10);


}



void selectlevel(){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
  int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();

if(tx >= 430 && tx <= 430 + 50){ // Если кнопка нажата
    if (mode == buf_mode){ //если условие выполняется 
      mode = (mode + 1) % 2; // Переключение режима (0, 1, 2)
    }
  }
  else{ //если условиен не выполняется
    buf_mode = mode;  //в буферную переменную записываем значение mode
  }

if(mode > 2){buf_mode = 0;} // если больше 2 то переключаем заново

switch (mode) {
    case 0:
      menu10();
      
      break;
    case 1:

      menu30();
      break;
  }
    }
    }
}

void menu5 (){
gfx->fillCircle(123 + 50 / 2, 100 + 50 / 2, 50 / 2, RGB565_BLACK);
    gfx->fillCircle(200 + 80 / 2, 85 + 80 / 2, 80 / 2, RGB565_BLACK);
    gfx->fillCircle(307 + 50 / 2, 100 + 50 / 2, 50 / 2, RGB565_BLACK);
playSelectedFile(13);

while(1){
touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();

//наш игрок
    Serial.printf("x=%d, y=%d\n", tx, ty);
if (tx >= 123 && tx <= 123 + 50 &&
    ty >= 100 && ty <= 100 + 50  ){ 
 //   gfx->fillScreen(RGB565_BLUE);
   playSelectedFile(15);
    while(1){
if (tx >= 5 && tx <= 5 + 40 &&
    ty >= 5 && ty <= 5 + 40  ){ 
    menu5();
    }
    }}
 //-------------------------------------------- 
// встроенные уровни
Serial.printf("x=%d, y=%d\n", tx, ty);
if (tx >= 200 && tx <= 200 + 80 &&
    ty >= 85 && ty <= 85 + 80  ){ 
   while(1){
 selectlevel();
   }}

//_________________ наши уровни
    Serial.printf("x=%d, y=%d\n", tx, ty);
if (tx >= 307 && tx <= 307 + 50 &&
    ty >= 100 && ty <= 100 + 50  ){ 
   gfx->fillCircle(60 + 50 / 2, 30 + 50 / 2, 50 / 2, RGB565_BLACK);
   gfx->fillCircle(290 + 200 / 2, 10 + 400 / 2, 400 / 2, RGB565_BLACK);
  gfx->fillCircle(140 + 50 / 2, 30 + 50 / 2, 50 / 2, RGB565_BLACK);
   playSelectedFile(14);
       while(1){
    touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
   if (tx >= 5 && tx <= 5 + 40 &&
    ty >= 5 && ty <= 5 + 40  ){ 
    menu5();
    }

    if (tx >= 140 && tx <= 140 + 50 &&
    ty >= 30 && ty <= 30 + 50  ){
playSelectedFile(8);
menu5();
    }
if (tx >= 290 && tx <= 290 + 100 &&
    ty >= 10 && ty <= 10 + 100  ){
       playSelectedFile(7);
       while(1){
        touchController.read();
  if (touchController.isTouched){
    for (int i=0; i<touchController.touches; i++){
    int tx = touchController.points[0].x;
    int ty = touchController.points[0].y;
    int screenW = gfx->width();
    int screenH = gfx->height();
       if (tx >= 5 && tx <= 5 + 40 &&
    ty >= 5 && ty <= 5 + 40  ){ 
    menu5();
    }}}}}

       }}}


//редактор
    }}}}}